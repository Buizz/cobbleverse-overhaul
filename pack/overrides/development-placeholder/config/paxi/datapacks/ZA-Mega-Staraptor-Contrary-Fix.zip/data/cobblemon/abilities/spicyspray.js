{
  onDamagingHit(damage, target, source, move) {
    if (!source.trySetStatus("brn", target) && !source.status && source.hasType("Fire")) {
      this.add("-immune", source);
    }
  },
  flags: {},
  name: "Spicy Spray",
  rating: 3
}
