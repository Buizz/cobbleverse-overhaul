{
  onChargeMove(pokemon, target, move) {
    if (move.id === "solarbeam" || move.id === "solarblade") {
      this.add("-activate", pokemon, "ability: Mega Sol");
      return false;
    }
  },
  onBasePowerPriority: 30,
  onBasePower(basePower, pokemon, target, move) {
    if (move.id !== "solarbeam" && move.id !== "solarblade") return;
    const weakWeathers = ["raindance", "primordialsea", "sandstorm", "hail", "snowscape"];
    if (weakWeathers.includes(this.field.effectiveWeather())) return this.chainModify(2);
  },
  onModifyTypePriority: -1,
  onModifyType(move, pokemon) {
    if (move.id === "weatherball") move.type = "Fire";
  },
  onModifyMovePriority: -1,
  onModifyMove(move, pokemon) {
    if (move.id === "weatherball") move.basePower = 100;
  },
  onTryHeal(damage, target, source, effect) {
    if (!effect || effect.id !== "synthesis") return;
    const weather = this.field.effectiveWeather();
    if (weather === "sunnyday" || weather === "desolateland") return;
    if (["raindance", "primordialsea", "sandstorm", "hail", "snowscape"].includes(weather)) {
      return this.chainModify([8, 3]);
    }
    return this.chainModify([4, 3]);
  },
  onWeatherModifyDamagePriority: 1,
  onWeatherModifyDamage(damage, attacker, defender, move) {
    const sunnyDay = this.dex.conditions.get("sunnyday");
    sunnyDay.onWeatherModifyDamage.call(this, damage, attacker, defender, move);
    return damage;
  },
  flags: {},
  name: "Mega Sol",
  rating: 3
}
