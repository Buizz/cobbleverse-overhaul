{
  onHitProtect(source, target, move) {
    if (move.flags["contact"]) {
      target.getMoveHitData(move).bypassProtect = this.effect;
      return false;
    }
  },
  flags: {},
  name: "Unseen Fist",
  rating: 2,
  num: 260,
  shortDesc: "This Pokemon's contact moves ignore protection and deal 1/4 the usual damage."
}
