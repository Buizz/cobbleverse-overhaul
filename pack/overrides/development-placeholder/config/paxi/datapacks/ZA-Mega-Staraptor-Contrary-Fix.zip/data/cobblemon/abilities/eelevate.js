{
  onSourceAfterFaint(length, target, source, effect) {
    if (effect && effect.effectType === "Move") {
      const bestStat = source.getBestStat(true, true);
      this.boost({ [bestStat]: length }, source);
    }
  },
  onTryHit(target, source, move) {
    if (target !== source && move.type === "Ground") {
      this.add("-immune", target, "[from] ability: Eelevate");
      return null;
    }
  },
  flags: { breakable: 1 },
  name: "Eelevate",
  rating: 4
}
