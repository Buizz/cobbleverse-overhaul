{
  onModifyAtkPriority: 5,
  onModifyAtk(atk, attacker, defender, move) {
    if (move.type === "Fire") return this.chainModify(1.5);
  },
  onModifySpAPriority: 5,
  onModifySpA(spa, attacker, defender, move) {
    if (move.type === "Fire") return this.chainModify(1.5);
  },
  flags: {},
  name: "Fire Mane",
  rating: 3.5
}
