{
  onDamage(damage, target, source, effect) {
    this.effectState.checkedBerserk = !(effect.effectType === "Move" && !effect.multihit);
  },
  onTryEatItem(item) {
    const healingItems = [
      "aguavberry", "enigmaberry", "figyberry", "iapapaberry", "magoberry", "sitrusberry", "wikiberry", "oranberry", "berryjuice"
    ];
    if (healingItems.includes(item.id)) return this.effectState.checkedBerserk;
    return true;
  },
  onAfterMoveSecondary(target, source, move) {
    this.effectState.checkedBerserk = true;
    if (!source || source === target || !target.hp || !move.totalDamage) return;
    const lastAttackedBy = target.getLastAttackedBy();
    if (!lastAttackedBy) return;
    const damage = move.multihit && !move.smartTarget ? move.totalDamage : lastAttackedBy.damage;
    if (target.hp <= target.maxhp / 2 && target.hp + damage > target.maxhp / 2) {
      this.boost({ spa: 1 }, target, target);
    }
  },
  flags: {},
  name: "Berserk",
  rating: 2,
  num: 201
}
