{
  onHitProtect(source, target, move) {
    if (move.flags["contact"]) {
      target.getMoveHitData(move).bypassProtect = this.effect;
      return false;
    }
  },
  flags: {},
  name: "Piercing Drill",
  rating: 1
}
